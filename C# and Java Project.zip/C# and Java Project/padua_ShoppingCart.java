import java.util.Scanner;
public class padua_ShoppingCart {
    
    public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    	
    double item1, quantity1, item2, quantity, quantity2,
      item3, quantity3, totalCost, pricebyqty;
    	
 
    	System.out.print("Enter the price of Ferrari : ");
    	item1 = scan.nextDouble();
    	
    	System.out.print("Enter price of Quantity : ");
    	quantity1 = scan.nextDouble();
    	
        System.out.print("Enter the price of Maserati : ");
    	item2 = scan.nextDouble();
    	
    	System.out.print("Enter price of Quantity : ");
    	quantity2 = scan.nextDouble();
   
   
    	System.out.print("Enter the price of Nissan : ");
    	item3 = scan.nextDouble();
    	
    	System.out.print("Enter price of Quantity : ");
    	quantity3 = scan.nextDouble();
    	
    	totalCost = item1 + item2 + item3;
    	quantity = quantity1 + quantity2 + quantity3;
    	pricebyqty = totalCost * quantity;
    	
    	System.out.println("Total Cost : " + totalCost);
    	System.out.println("Total Quantity : " + quantity);
    	System.out.println("Total Amount : " + pricebyqty); 	
    	
    }
}
