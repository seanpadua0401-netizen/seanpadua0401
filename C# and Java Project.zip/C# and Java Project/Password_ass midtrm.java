import java.util.Scanner; 
public class Password {
    
    public static void main(String[] args) {
    	Scanner scanner = new Scanner (System.in);
    	
    	System.out.println("Enter password: ");
    	String input = scanner.nextLine ();
    	 
    	String username = "sean124";
    	
    	if (username.length() >= 8 && username.length() <= 20){
    		System.out.println ("Username length is valid.");
    	}	
    		else {
    			System.out.println ("Username must be between 8 and 20 characters long.");
    		}
    
    }
}
