import java.util.Scanner; 
public class multiplication_SeanP {
    
    public static void main(String[] args) { 	
    Scanner scanner = new Scanner(System.in);
    
    int number;
    int i = 1;
    System.out.println("Enter a number: ");
    number = scanner.nextInt();
    
    while(i <= 10){
    	System.out.println(number + " * " + i + " = " + (number * i ));
    	i++;
    }
    }
}