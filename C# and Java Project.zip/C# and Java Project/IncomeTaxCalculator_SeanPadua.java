
 
public class IncomeTaxCalculator_SeanPadua {
    
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    	
    	
    	System.out.println("Enter the anual income: ");
    	double income = scanner.nextDouble ();
    	    
         
         double tax2 = income * 0.10;
         double tax3 =  income * 0.20;
         double tax4 =  income * 0.30;	
         		
    	if (income <=250000){
    	System.out.print ("Total Income Tax: No tax" );
    		}   
    	else if (income < 500000){
    	System.out.print ("Total Income Tax: " + tax2);
    	else if (income < 100000){ 
    	System.out.print ("Total Income Tax: " + tax3);	
    	else if{
    	System.out.print ("Total Income Tax: " + tax4);	
    	else if (income < 10000){
    	System.out.print ("Total Income Tax: " +);	
    			}		
    			}		
    			}	
    			