
import java.util.Scanner; 
public class Padua_Sean {
    
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    int Beachtrip; 
    int foodExpenses = 150;
    int perNights = 1000;
    int travelExpenses = 500;
     	
 
    	System.out.println("Number of Days of your Beach Trip: ");
    	Beachtrip = scanner.nextInt();
    	
    	int T = * 150 Beachtrip;
    
    
    	System.out.println(" Beach Trip Expenses Breakdown");
    	System.out.println("Food expenses" + Beachtrip + " * " + T);
    	System.out.println("Accomodation"+ 2 + "nights* 1000Php/night = 2000");
    	  
    	  int T1 = 2 * 1000;
    	  int grandTotal = T+T1+TravelExpeses;
    	  
    	  
    	  System.out.println("Travel Expenses: " +travelExpenses);
    	  System.out.println("Grant Total : "+grandTotal);
    	  
    	  
    	
    	 
    	 
   
    	 
    
    	
    	
    	
    	
    	
    }
}
